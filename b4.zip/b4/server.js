const express=require("express")
const mongoose=require("mongoose")
const app=express()
app.use(express.json())  
const port=5000
mongoose.connect("mongodb://localhost:27017/csea_athidi")
.then(()=>{
    console.log("mongodb is connected")
})
.catch((e)=>{
    console.log(`error is ${e}`)
})
const studentSchema=mongoose.Schema({
    name:"String",
    age:"Number",
    gender:"String",
    course:"String",
    year:"Number",
    marks:"Number",
    city:"String",
    email:"String"
})
const student=mongoose.model("students",studentSchema)

app.post("/create_student",async(req,res)=>{
    const s=await student.insertOne(req.body)
    await res.send(s)
})
app.post("/create_students",async(req,res)=>{
    const s=await student.insertMany(req.body)
    await res.send(s)
})

app.get("/students",async(req,res)=>{
    const s= await student.find()
    await res.send(s)
    
})
  
app.get("/student",async(req,res)=>{
    const s=await student.find(req.body)
    await res.send(s)
})

app.get("/student/:id",async(req,res)=>{
    const s=await student.find({_id:req.params.id})
    await res.send(s)

})

app.put("/updateo",async(req,res)=>{
    const s=await student.updateOne({name:req.body.name},
                                    {$set:{city:req.body.city}})

            await res.send(s)
})


app.put("/updatem",async(req,res)=>{
    const s=await student.updateMany({course:req.body.course},
                                        {$set:{marks:req.body.marks}})
        await res.send(s)
})

app.delete("/deleteo",async(req,res)=>{
    const s=await student.deleteOne({name:req.body.name})
    await res.send(s)
})

app.delete("/deletem",async(req,res)=>{
    const s=await student.deleteMany({course:req.body.course})
    await res.send(s)
}) 

app.delete("/delete/:stid",async(req,res)=>{
    const s=await student.deleteOne({_id:req.params.stid})
    await res.send(s)
})
app.delete("/deleteid",async(req,res)=>{
    const s=await student.deleteOne({_id:req.body._id})
    await res.send(s)
})



app.listen(port,()=>{
console.log(`server is running at http://localhost:${port}`)
})
